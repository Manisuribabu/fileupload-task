import React, { useState } from "react";
import "./App.css";

import Dropzone from "react-dropzone";

const Sample =()=>{
    
  const [files, setFiles] = useState([]);
  
  const handleDrop = acceptedFiles =>{
    console.log(acceptedFiles);
  setFiles(files.concat(acceptedFiles[0]));
  }
  return (
    <div className="App">
      <Dropzone onDrop={handleDrop}>
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps({ className: "dropzone" })}>
            <input {...getInputProps()} />
            <p>Drag'n'drop files, or click to select files</p>
          </div>
        )}
      </Dropzone>
      <div>
        <strong>Files:</strong>
        <div>
          {files.map(file => (
            <div>
              <ul className="list-style">
                <li>{file.name}</li>
             </ul>
                </div>
          ))}
        </div>
      </div>
    </div>)
}
export default Sample;